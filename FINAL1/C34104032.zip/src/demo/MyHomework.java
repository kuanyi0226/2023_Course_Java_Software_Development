package demo;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MyHomework {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ArrayList<String> words = new ArrayList<String>();
		ArrayList<String> ids = new ArrayList<String>();
		
		String inputLine = scanner.nextLine();
		//System.out.println(inputLine);
		
		int idNum = scanner.nextInt();
		//System.out.println(idNum);
		
		//token
		StringTokenizer tokenizer = new StringTokenizer(inputLine);
		while (tokenizer.hasMoreElements()) {
			words.add(tokenizer.nextToken());	
		}
//		for(int i = 0; i < words.size();i++) {
//			System.out.println(words.get(i));
//		}
		
		//read id inputs
		for(int i = 0; i <idNum; i++) {
			ids.add(scanner.next());
		}
//		for(int i = 0; i <idNum; i++) {
//			System.out.println(ids.get(i));
//		}
		
		boolean result;
		int tempWordIndex;
		//check
		for(int i = 0; i <idNum; i++) {
			result = false;
			for(int j = 0; j < words.size(); j++) {
				//id too small
				if(ids.get(i).length() < words.get(j).length()) {
					continue;
				}
				//perfectly match
				if(words.get(j).contains(ids.get(i))) {
					result = true;
					break;
				}
				//complex case
				tempWordIndex = 0;
				for(int k = 0; k < ids.get(i).length();k++) {
					if(ids.get(i).charAt(k) == words.get(j).charAt(tempWordIndex)) {
						tempWordIndex++; 
						if(tempWordIndex >= words.get(j).length()) {
							break;
						}
					}
				}
				if(tempWordIndex >= words.get(j).length()) {
					result = true;
					break;
				}
			}
			
			if(result == true)
				System.out.println("True");
			else {
				System.out.println("False");
			}
		}
	}
}
/*
house dog cat
3
iamdoghero
hereofuse
god
 * */
