package hw4;

public class Card {
	int number = 0;
	char shape = 'A';
	boolean used = false;
	
	public Card(int number, char shape) {
		this.number = number;
		this.shape = shape;
	}
}
